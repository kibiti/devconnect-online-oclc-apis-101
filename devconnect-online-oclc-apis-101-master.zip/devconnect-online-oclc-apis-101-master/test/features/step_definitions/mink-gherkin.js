const cucumber = require('cucumber');
const mink = require('cucumber-mink');

mink.gherkin(cucumber);